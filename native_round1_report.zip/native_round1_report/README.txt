VHH CDR 设计项目 — RL 后训练报告包（IF 路线 + 扩散路线）
==========================================================

内容
----
docs/
  RL_COMBINED_REPORT.md          合并报告（IF-RL + 扩散-RL；数据/方法/指标/结果/结论）
  combined_figures/              合并报告图（3张，两类方法一起重画）
    fig1_scores.png              全部10个方法 valid100 CDR margin + 全局 nativeness
    fig2_curves.png              两条路训练曲线（IF两轮 / DPO z / implicit acc）
    fig3_tradeoff.png            reward-geometry 权衡 + 两条路逐样本散点（r≈0）
  NATIVE_AUDIT.md                扩散路线 Phase A 审计
  NATIVE_IMPLEMENTATION_REPORT.md 扩散路线实现报告
  NATIVE_ROUND1_RESULTS.md       扩散路线结果报告（Gate/训练/评测/refold/决策）
  figures/                       扩散路线单独报告图（4张）

results/
  eval_valid100_summary.json     扩散路线主评测（4 arm + base）
  eval_valid100_per_case.csv     100 cases 逐 case 数值
  heldout/                       held-out checkpoint 选择
  pools/                         N0 base pool 统计
  pairs/                         192 preference pairs + gap 分布
  refold/                        扩散路线 refold per-sample
  if_refold/                     IF 路线 refold per-sample + manifest
  panels/                        两条路线完整分类器面板原始数据（合并图的数据源）
    if_arm3_scores.jsonl         IF 路线 7 臂 × 5600 序列全字段
    native_panel_valid100.jsonl  扩散路线 5 臂 × 4000 序列全字段
    native_panel_valid100_summary.json
  sequences/                     全部样本序列+reward（base 与各训练臂，JSONL）
  smoke/                         工程 Gate 报告 + 单元测试结果
  training/                      两条路线训练曲线（IF 的见 runs 说明；此处为原生4臂）

关键数字（valid100, 100 cases × 8 samples, reward = CDR margin）
----------------------------------------------------------------
base IF               1.90
IF-RL R1              1.96（nativeness reward）
IF-RL R2              6.89   ← IF 路线后训练结果
native base           6.58
N1 RWR                7.16（+0.58, 71/100 胜）
N2 full DPO           9.28（+2.70, 93/100 胜）
N3 fake DPO           9.37（+2.80, 95/100 胜）← 最佳，追平 ProteinMPNN
N4 fake+anchor        9.09（+2.51, 93/100 胜）
G0 (ProteinMPNN)      9.48
M1-β1                 13.21（偏科：全局 nativeness 0.868）
invalid/UNK = 0；FR mismatch = 0；unique ≈ 1.0
两条路线共同发现：分类器分数与重折叠结构保真度几乎无关（r=+0.015 / +0.019）

复现
----
代码在 vhh_boltzgen_rl/（src/vhh_rl/native_atom14/ 为扩散路线；IF-RL 在 src/vhh_rl/rl/），
入口 bash run.sh native-*。所有计算经 Slurm 提交。
