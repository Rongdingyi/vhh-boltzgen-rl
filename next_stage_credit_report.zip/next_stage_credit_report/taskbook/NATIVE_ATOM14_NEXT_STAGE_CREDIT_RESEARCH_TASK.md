# Native Atom14 Post-training 下一阶段研究任务书
## 目标：从“Native Diffusion-DPO 能工作”推进到“面向 joint sequence–structure diffusion 的信用分配算法”

> 适用项目：`vhh_boltzgen_rl`  
> 当前基础结果：`native_round1_report.zip / NATIVE_ROUND1_RESULTS.md`  
> 当前最佳 native baseline：N3 CDR-Fake-Atom Diffusion-DPO  
> 本任务书用途：直接交给 OpenCode / Codex / Claude Code 执行。  
>
> **重要：本阶段不是继续刷 classifier reward。**
> 当前要回答的是：为什么标准/均匀的 sequence-level preference 会让 joint sequence–structure diffusion 的结构自洽性变差，以及怎样把一个 sequence-level black-box reward 更准确地分配到“哪些 residue、哪些 atom、哪些 diffusion noise level”。
>
> **本阶段不更换 reward。** 主 reward 仍固定为现有 `cdr_camelid_margin`。
>
> 完成本文件中 Phase A–D 后必须停下来产出报告；不要自动进入大规模论文实验。

---

# 0. 当前结论与下一步决策

Round-1 已经证明：

\[
\boxed{\text{Native atom14 Diffusion-DPO 可以稳定提高 CDR classifier reward}}
\]

valid100：

| Arm | CDR margin | Δ vs Base | W/T/L |
|---|---:|---:|---:|
| Native Base | 6.578 | — | — |
| N1 RWR | 7.161 | +0.583 | 71/0/29 |
| N2 Full-Atom14 DPO | 9.279 | +2.702 | 93/0/7 |
| **N3 Fake-Atom DPO** | **9.374** | **+2.796** | **95/0/5** |
| N4 Fake+Anchor | 9.090 | +2.512 | 93/0/7 |

但 refold：

| Arm | CDR RMSD | CDR3 RMSD | pLDDT(CDR) |
|---|---:|---:|---:|
| Base | 1.860 | 2.347 | 0.623 |
| N1 | 1.839 | 2.312 | 0.626 |
| N2 | 1.999 | 2.502 | 0.622 |
| **N3** | **2.090** | **2.709** | **0.614** |
| N4 | 2.206 | 2.823 | 0.621 |

所以当前最明确的问题不是：

> DPO 能不能把 reward 学上去？

这个已经回答了。

真正的问题变成：

\[
\boxed{
\text{为什么 sequence-level preference 被学进去以后，sequence–structure compatibility 会受损？}
}
\]

本阶段主假设：

> **标准 Diffusion-DPO 存在 credit mismatch：一个最终 sequence-level reward 被粗粒度地作用到很多 residue、很多 fake atoms，以及整个 diffusion noise range；但真正决定 reward 的 residue 可能是稀疏的，而 residue identity 也不一定在所有 diffusion timestep 上同等可辨认。**

因此下一阶段研究两类信用分配：

1. **Spatial credit assignment**
   - 哪些 CDR residue 真正贡献 classifier reward？
   - 哪些 fake atoms 应该获得 preference gradient？

2. **Temporal credit assignment**
   - sequence identity 在 diffusion 的哪个噪声阶段开始稳定？
   - sequence reward 是否应该主要作用在低噪声阶段，而不是所有 sigma？

最终候选方法：

\[
\boxed{
\text{Counterfactual Spatiotemporal Preference Optimization}
}
\]

先不要正式命名论文方法；代码中暂用：

```text
CF-ST-DPO
```

---

# 1. 为什么先研究 credit assignment，而不是继续调 N4 anchor

N4 使用：

\[
L =
L_{\mathrm{DPO}}^{fake}
+
\lambda L_{\mathrm{reference-anchor}}
\]

它确实让 parameter drift：

```text
N3: 3.29
N4: 2.93
```

下降。

但 refold：

```text
N3 CDR RMSD = 2.090
N4 CDR RMSD = 2.206
```

反而更差。

所以当前结果已经说明：

\[
\boxed{
\text{靠“别离 reference 太远”并不等价于“保持 sequence–structure compatibility”}
}
\]

下一步不要优先做：

```text
lambda_anchor = 0.01 / 1 / 10
```

这种固定系数 sweep。

优先研究：

> preference gradient 本身到底是不是打错了位置和 diffusion 阶段。

---

# 2. 从当前结果包得到的两个新增诊断事实

coding agent 在开始新实验前必须首先复现下面两个统计，不能只相信本文档。

## 2.1 一个 global preference pair 平均改了很多 residue

数据：

```text
results/pairs/pairs_train.jsonl
results/sequences/train.jsonl
```

当前 192 个 preference pairs：

```text
winner/loser 全部同长度
FR mismatch = 0
```

因此同一 case winner/loser 的序列差异全部来自 CDR design positions。

当前统计：

```text
mean Hamming difference   ≈ 15.60 residues
median Hamming difference ≈ 15.5 residues
min                         3
max                        31
```

总 differing positions：

```text
2996
```

这意味着现在 N3 的一个 preference pair：

```text
winner reward > loser reward
```

通常同时包含约 15–16 个 residue 变化。

标准 N3 实际上无法回答：

> 这 15 个变化中，哪些真的导致 reward gap？

---

## 2.2 变了多少 residue 和 reward gap 几乎没关系

当前 pair：

```text
corr(number_of_different_residues, reward_gap)
```

约：

```text
Pearson  ≈ 0.07
Spearman ≈ 0.04
```

所以：

```text
改得更多
```

并不意味着：

```text
reward gap 更大
```

这是 credit sparsity / epistasis 值得研究的第一个信号。

---

## 2.3 classifier reward 与结构自洽性不是同一个轴

把：

```text
results/refold/manifest.csv
results/refold/native_refold_results_per_sample.csv
results/sequences/valid100*.jsonl
```

按：

```text
case_id + sequence + arm
```

对齐后，400 条 refold sample：

```text
corr(reward, CDR RMSD)     ≈ +0.019 Pearson
corr(reward, CDR pLDDT)    ≈ -0.563 Pearson
corr(reward, CDR recovery) ≈ -0.447 Pearson
```

各 arm 内：

```text
reward vs CDR RMSD：大多约 -0.10 ~ +0.07
reward vs pLDDT(CDR)：约 -0.49 ~ -0.65
```

所以当前 failure 不能简单描述成：

```text
reward high → RMSD high
```

更准确的是：

> classifier reward 基本没有提供结构自洽性的 credit，而且高 classifier score 与 fold-back confidence 还存在明显反向趋势。

coding agent 必须在：

```text
docs/NEXT_STAGE_DIAGNOSTIC_REPRO.md
```

重新生成这些结果。

---

# 3. 与现有论文的边界：必须避免重复创新

开始编码前，在：

```text
references/NEXT_STAGE_RELATED_WORK.md
```

记录并简要读以下工作：

## ProteinDPO / experimental-fitness DPO

2026 Nature Methods：

```text
Aligning protein-generative models to experimental fitness with ProteinDPO
```

已有：

```text
sequence-level DPO
ranked DPO
weighted DPO
experimental scalar fitness
```

所以不能把：

```text
“用 scalar reward 做 protein DPO”
```

当创新。

---

## ResiDPO / EnhancedMPNN

```text
Improving Protein Sequence Design through Designability Preference Optimization
```

已有：

```text
residue-level structural reward
residue-level preference optimization
preserve already-good residues
```

所以不能写：

```text
“首次做 residue-level protein DPO”
```

我们的区别必须是：

> **我们只有一个 sequence-level black-box reward，没有 residue-level annotation；需要通过 counterfactual interventions 从 sequence-level reward 自动恢复 residue credit，然后把 credit 映射到 continuous atom14 geometry。**

---

## ProtAlign / ProteinOPD

2026 已经在做：

```text
multi-objective preference alignment
designability preservation
semi-online DPO
catastrophic forgetting control
```

所以当前阶段不要把：

```text
classifier + structure score 加权
```

作为主创新。

---

## Generic timestep-aware Diffusion-DPO

generic image diffusion 已经有 timestep-aware / curriculum DPO。

因此：

```text
“低噪声 timestep 加大权重”
```

单独不够当论文创新。

我们要研究的是：

> 在 **geometry-encoded sequence–structure co-design diffusion** 中，sequence identity 的空间和时间 credit 如何同时被错误分配。

---

# 4. 最终研究假设

本阶段只验证 4 个假设。

## H1 — Spatial credit is sparse

对于一个：

\[
R(S^+) > R(S^-)
\]

的 pair，winner 与 loser 平均约有 15.6 个 CDR 位点不同。

假设：

> 真正支撑 reward gap 的 residue 只占其中一部分。

---

## H2 — Uniform fake-atom DPO contains off-target updates

N3 把所有 CDR fake atoms 都视作 preference-relevant。

假设：

> 低 credit / zero credit residue 接受到 preference update，是结构 self-consistency 退化的重要来源之一。

---

## H3 — Sequence identity emerges non-uniformly over diffusion time

BoltzGen atom14 同时生成：

```text
backbone geometry
fake side-chain geometry
```

假设：

> global structure 和 sequence-carrying fake geometry 在 diffusion trajectory 中并不是同步收敛；sequence identity 可能在相对较低 noise 时才稳定。

---

## H4 — Spatiotemporal credit improves the reward–geometry Pareto frontier

假设：

> 只在 classifier 真正在乎的 residue，并主要在 sequence identity 已可辨认的 diffusion 阶段施加 preference，可以保留 N3 的 reward gain，同时降低 CDR refold RMSD / pLDDT degradation。

---

# 5. 整体执行顺序

严格：

```text
Phase A0: 当前统计复现
        ↓
Phase A1: Counterfactual residue credit audit
        ↓
Phase A2: CDR-region counterfactual audit
        ↓
Decision Gate A
        ↓
Phase B1: Diffusion sequence-emergence trajectory audit
        ↓
Decision Gate B
        ↓
Phase C1: Counterfactual-weighted DPO pilot
Phase C2: random/shuffled controls
        ↓
Decision Gate C
        ↓
Phase D1: Temporal-weighted DPO pilot
Phase D2: Spatial + temporal combined DPO
        ↓
held-out + fixed 20-case refold
        ↓
Decision Gate D
        ↓
STOP
```

不要一开始同时写所有方法。

---

# 6. 新目录

在现有：

```text
vhh_boltzgen_rl/
```

新增：

```text
src/vhh_rl/credit/
├── __init__.py
├── pair_analysis.py
├── cdr_regions.py
├── counterfactual.py
├── credit_metrics.py
├── credit_cache.py
├── residue_weights.py
├── trajectory_audit.py
├── temporal_schedule.py
├── weighted_dpo.py
└── controls.py
```

脚本：

```text
scripts/
├── next_reproduce_stats.py
├── next_build_counterfactuals.py
├── next_score_counterfactuals.py
├── next_analyze_credit.py
├── next_audit_trajectory.py
├── next_train_cf_dpo.py
├── next_train_temporal_dpo.py
├── next_train_st_dpo.py
├── next_eval.py
└── run_next_stage.sh
```

文档：

```text
docs/
├── NEXT_STAGE_DIAGNOSTIC_REPRO.md
├── COUNTERFACTUAL_CREDIT_AUDIT.md
├── TEMPORAL_CREDIT_AUDIT.md
├── NEXT_STAGE_IMPLEMENTATION.md
└── NEXT_STAGE_RESULTS.md
```

---

# 7. Phase A0 — 先复现当前诊断统计

执行：

```bash
bash run.sh next-reproduce
```

输入：

```text
runs/native_pool/
native_round1_report/results/
```

至少重新输出：

## Pair stats

```text
n_pairs
Hamming mean/median/p10/p25/p75/p90
reward gap stats
Pearson/Spearman(Hamming, reward_gap)
```

## Refold correlations

全体 + 每 arm：

```text
reward vs CDR RMSD
reward vs CDR3 RMSD
reward vs pLDDT(CDR)
reward vs CDR recovery
```

输出：

```text
runs/next_stage/repro/pair_stats.json
runs/next_stage/repro/refold_correlations.csv
docs/NEXT_STAGE_DIAGNOSTIC_REPRO.md
```

必须与现有结果近似一致。

---

# 8. Phase A1 — Counterfactual residue credit audit

这是当前最高优先级实验。

不训练模型。

只使用：

```text
192 train preference pairs
现有 CDR classifier
```

---

# 9. Counterfactual 定义

对 pair：

\[
(S^+,S^-)
\]

其中：

\[
R(S^+) > R(S^-)
\]

找所有：

```text
S_plus[i] != S_minus[i]
```

的 CDR design residue。

对每个 differing position \(i\)，构造两个 counterfactual。

---

## 9.1 Winner-drop intervention

把 winner 的 residue 换成 loser residue：

\[
S_{i}^{+\leftarrow-}
\]

定义：

\[
c_i^{drop}
=
R(S^+)
-
R(S_{i}^{+\leftarrow-})
\]

解释：

```text
拿掉 winner 在 i 的 residue 后，reward 掉多少？
```

---

## 9.2 Loser-gain intervention

把 loser 的 residue 换成 winner residue：

\[
S_{i}^{-\leftarrow+}
\]

定义：

\[
c_i^{gain}
=
R(S_{i}^{-\leftarrow+})
-
R(S^-)
\]

解释：

```text
把 winner 的 i residue 放进 loser 后，reward 涨多少？
```

---

# 10. 为什么必须双向 intervention

只看：

```text
winner → mutant
```

会受到 winner context 的 epistasis 影响。

只看：

```text
loser → mutant
```

同样有 context bias。

所以同时保留：

```text
c_drop
c_gain
```

并分析二者 agreement。

---

# 11. 本轮 counterfactual 查询规模

当前 pair：

```text
total differing positions = 2996
```

双向 intervention：

```text
约 5992 条 counterfactual sequences
```

再加原始 winner/loser：

数量很小。

必须：

```text
batch scorer
cache by sequence SHA1
```

不要逐条启动 scorer subprocess。

---

# 12. Counterfactual 序列 hard checks

每条 CF sequence：

```text
长度不变
FR 不变
只允许修改指定 design position
AA 必须属于 20 canonical
```

assert：

```python
hamming(original, cf) == 1
```

如果 position 属于 FR：

立即 FAIL。

---

# 13. CDR position mapping

不要自己用固定 residue index 猜 CDR1/2/3。

优先复用：

```text
现有 manifest
现有 CDR classifier segmentation
现有 VHH project 的 CDR mask
```

必须保证：

```text
classifier 用的 CDR 区域
==
credit analysis 标记的 CDR 区域
```

如果当前项目没有保存 CDR1/2/3 细分：

先从 scorer 实际 preprocessing 中提取。

不要额外引入不同编号体系造成口径变化。

---

# 14. 计算 4 种 residue credit

每个 differing residue 保存：

```text
c_drop
c_gain
```

再计算：

## Signed average

\[
c_i^{avg}
=
\frac12(c_i^{drop}+c_i^{gain})
\]

## Conservative positive credit

\[
c_i^{cons}
=
\begin{cases}
\min(c_i^{drop},c_i^{gain}), & c_i^{drop}>0 \land c_i^{gain}>0\\
0, & \text{otherwise}
\end{cases}
\]

这个是后面主训练优先使用的 credit。

原因：

> 只有 winner→loser 会掉分、loser→winner 会涨分，两边都支持时，才认为 winner residue 是可靠 positive preference。

## Context disagreement

\[
d_i=
|c_i^{drop}-c_i^{gain}|
\]

## Sign agreement

```text
sign(c_drop) == sign(c_gain)
```

---

# 15. Counterfactual audit 必须算的指标

对每个 pair：

```text
n_diff
n_positive_consistent
positive_fraction
sign_agreement_rate
credit_abs_sum
credit_positive_sum
```

还要算：

## Top-k credit concentration

对：

```text
top 10%
top 20%
top 30%
top 50%
```

residues，报告占：

```text
Σ positive consistent credit
```

的比例。

---

## Effective number of residues

\[
n_{eff}
=
\frac{
(\sum_i c_i)^2
}{
\sum_i c_i^2+\epsilon
}
\]

使用：

```text
c_i = c_cons
```

报告：

\[
n_{eff}/n_{diff}
\]

越小表示 credit 越集中。

---

## Reward-gap explanation diagnostic

只作为诊断：

\[
C_{sum}
=
\sum_i c_i^{avg}
\]

计算：

```text
corr(C_sum, reward_gap)
```

注意：

> 由于 epistasis，不能要求 C_sum == reward_gap。

不要把 additivity 当 hard assumption。

---

# 16. Credit sparsity 的 Decision Gate A

定义：

### Strong support

若：

```text
median(top30% positive-credit mass) >= 0.60
AND
median(n_eff / n_diff) <= 0.60
```

则：

```text
H1 = STRONG SUPPORT
```

---

### Medium support

若：

```text
top30 mass = 0.45–0.60
```

或者 sparsity 只在 CDR3 等部分区域明显：

```text
H1 = PARTIAL SUPPORT
```

仍继续 Region/Residue DPO pilot。

---

### Weak support

若：

```text
top30 mass < 0.45
AND
n_eff/n_diff > 0.75
```

则：

```text
residue-level sparsity 假设较弱
```

不要强推 sparse residue method。

下一步优先看：

```text
CDR-region credit
temporal credit
```

---

# 17. Phase A2 — CDR-level counterfactual

因为单 residue intervention 会受 epistasis 影响，再额外做 region counterfactual。

对：

```text
CDR1
CDR2
CDR3
```

分别：

### Winner drop region

winner 的整个 CDRk 替换成 loser 的 CDRk：

\[
G_k^{drop}
=
R(S^+)
-
R(S_{CDR_k}^{+\leftarrow-})
\]

### Loser gain region

\[
G_k^{gain}
=
R(S_{CDR_k}^{-\leftarrow+})
-
R(S^-)
\]

每 pair 最多：

```text
6 extra scorer queries
```

总共约：

```text
1152 queries
```

---

# 18. Region audit

报告：

```text
CDR1 contribution
CDR2 contribution
CDR3 contribution
```

以及：

```text
哪个 CDR 是 dominant region
region sign agreement
```

比较：

```text
region credit
vs
sum of residue credits in that region
```

差异可以作为 epistasis 指标。

---

# 19. Counterfactual 输出

保存：

```text
runs/next_stage/counterfactual/
├── counterfactual_sequences.jsonl
├── counterfactual_scores.jsonl
├── residue_credit.csv
├── region_credit.csv
├── pair_credit_summary.csv
├── credit_stats.json
└── figures/
```

图至少：

1. credit Lorenz / cumulative mass curve；
2. n_diff vs n_eff；
3. CDR1/2/3 credit distribution；
4. c_drop vs c_gain；
5. reward gap vs total signed credit；
6. top-k mass boxplot。

报告：

```text
docs/COUNTERFACTUAL_CREDIT_AUDIT.md
```

---

# 20. Phase B1 — Diffusion trajectory sequence-emergence audit

这是第二个最高信息增益实验。

不训练。

目的：

> 看 sequence identity 是在 diffusion trajectory 的什么时候稳定下来的。

---

# 21. 数据量

先用：

```text
train: 8 cases
held-out: 8 cases
每 case: 8 trajectories
```

总：

```text
128 trajectories
```

用 frozen native base BoltzGen。

采样参数必须和 Round-1 一致：

```text
sampling_steps = 50
same step_scale schedule
same noise_scale schedule
```

---

# 22. 必须保存完整 `x0_coords_traj`

官方 sampler 已返回：

```text
coords_traj
x0_coords_traj
```

必须同时保存对应：

```text
sigma / step index
```

如果当前 wrapper 丢掉 sigma：

修改 adapter 让 sampling audit path 返回 schedule。

不要改 sampler 方程。

---

# 23. 对每个 diffusion step 的 x0 estimate 做什么

对每个：

\[
\hat X_0^{(t)}
\]

尝试调用官方：

```python
res_from_atom14()
```

得到：

```text
sequence_t
```

若 decode invalid：

记录 invalid。

最终：

```text
sequence_final
```

---

# 24. 每个 timestep 的 sequence metrics

对 CDR：

## Final-sequence recovery

\[
Q_{seq}(t)
=
Identity(
S_t^{CDR},
S_{final}^{CDR}
)
\]

## Stable residue fraction

对 residue i：

如果从 timestep t 开始直到 final：

```text
decoded AA 不再变化
```

则认为 residue 已 stable。

报告：

\[
Q_{stable}(t)
\]

## Reward convergence

若 sequence_t valid：

\[
R_t = classifier(S_t)
\]

报告：

```text
corr(R_t, R_final)
MAE(R_t, R_final)
```

---

# 25. 每个 timestep 的 geometry metrics

同时对：

```text
FR backbone
CDR backbone
fake atoms
```

计算与 final \(X_0\) 的 RMSD。

先按 FR backbone rigid align。

得到：

```text
FR backbone convergence
CDR backbone convergence
fake-atom convergence
```

---

# 26. 核心要画的图

横轴统一：

```text
log sigma
或 normalized diffusion progress [0,1]
```

纵轴：

```text
CDR final-sequence identity
stable residue fraction
classifier reward convergence
FR backbone RMSD to final
CDR backbone RMSD to final
fake atom RMSD to final
```

我们最关心：

> backbone geometry 是否早于 sequence identity 稳定。

---

# 27. 定义 sequence-emergence threshold

找到：

\[
\sigma_{seq}
\]

使：

```text
median CDR final-sequence identity >= 0.80
```

并且：

```text
median valid decode rate >= 0.90
```

若两个条件都达到。

同时记录：

\[
\sigma_{90}
\]

对应 90% identity。

---

# 28. Temporal Decision Gate B

### Strong temporal separation

如果：

```text
backbone 已基本收敛
但 CDR sequence identity 仍明显低
```

存在明显时间窗口，例如：

```text
CDR backbone normalized convergence > 0.8
while
sequence recovery < 0.5
```

则：

```text
H3 = STRONG SUPPORT
```

---

### Weak temporal separation

如果 sequence 和 backbone 几乎同步收敛：

```text
H3 = WEAK
```

则后面 temporal DPO 只做一个小 ablation，不作为主算法。

---

# 29. 构造 temporal weight

若 H3 成立，拟合：

\[
g(\sigma)
=
sigmoid
\left(
\frac{
\log\sigma_{seq}-\log\sigma
}{
\tau
}
\right)
\]

要求：

```text
sigma 大 → g 接近 0
sigma 小 → g 接近 1
```

第一版：

```text
tau = 0.5
```

不要 sweep。

同时保存一个 hard version：

```python
g_hard = 1 if sigma <= sigma_seq else 0
```

作为 ablation。

---

# 30. Phase C — Spatial counterfactual DPO

只有 Gate A 至少 Medium support 才正式做。

---

# 31. 主方法 C1：CF-weighted Fake-Atom DPO

仍使用 Round-1：

```text
192 pairs
same base checkpoint
same β=10 initial setting
same paired sigma/noise/rigid augmentation
same trainable scope
```

只改变：

```text
preference atom weighting
```

---

# 32. Counterfactual residue weight

对 pair 的 differing residue：

使用：

\[
u_i = c_i^{cons}
\]

若：

```text
Σ u_i > 0
```

归一化：

\[
w_i^{cf}
=
\frac{u_i}{\sum_j u_j}
\]

为了避免过度尖锐，加入 uniform floor：

\[
\boxed{
\tilde w_i
=
(1-\eta)\frac{1}{n_{diff}}
+
\eta w_i^{cf}
}
\]

第一版固定：

```text
eta = 0.75
```

不要 sweep。

---

# 33. 如果 pair 所有 c_cons 都是 0

fallback：

```text
uniform over differing CDR residues
```

不要丢弃 pair。

同时记录：

```text
cf_fallback_pair_rate
```

如果 fallback > 40%：

说明 conservative credit 太严格。

再启用：

```text
positive signed-average credit
```

作为 fallback。

---

# 34. Same-residue positions 的处理

如果：

```text
winner[i] == loser[i]
```

则：

```text
preference weight = 0
```

原因：

> sequence reward 无法证明同一 residue 对应的两套 fake geometry 哪一套更应该被偏好。

这正是和 N3 的关键区别。

---

# 35. Residue-weighted denoising loss

现有 N3：

```text
all CDR fake atoms uniform
```

改成按 residue 计算：

\[
\ell_{\theta,i}^{w}
\]

\[
\ell_{\theta,i}^{l}
\]

每个 residue：

```text
只用该 residue 的 fake atom mask
```

global rigid alignment 仍然：

```text
先用 full resolved atoms 完成
```

绝对不能每 residue 独立 align。

---

# 36. Weighted pair loss

计算：

\[
\ell_\theta^w
=
\sum_i
\tilde w_i
\ell_{\theta,i}^w
\]

\[
\ell_\theta^l
=
\sum_i
\tilde w_i
\ell_{\theta,i}^l
\]

reference 同理。

然后仍然用标准：

\[
z=
-\frac{\beta}{2}
[
(\ell_\theta^w-\ell_\theta^l)
-
(\ell_{ref}^w-\ell_{ref}^l)
]
\]

\[
L_{CF-DPO}
=
-\log\sigma(z)
\]

第一版不要改 DPO 数学形式。

只改 credit aggregation。

---

# 37. C1 的核心对照

至少四个：

## B0 — N3 Uniform Fake DPO

直接复用已有结果。

## B1 — Random Sparse Control

对每个 pair：

```text
非零 residue 数量
weight entropy
```

尽量匹配 CF weights。

但 residue 随机选。

目的：

> 排除“只是减少更新 residue 数量”就能改善 geometry。

---

## B2 — Weight-Shuffle Control

把真实 CF weights：

```text
在同一 pair differing positions 内随机 shuffle
```

保留：

```text
同样的 weight distribution
```

但破坏 residue-credit 对应关系。

这是最关键 control。

---

## B3 — CF-weighted DPO

真实 counterfactual weights。

---

# 38. 可选 B4 — Region-CF DPO

如果 Phase A2 显示：

```text
CDR-level credit 很稳定
```

则用：

```text
G_CDR1
G_CDR2
G_CDR3
```

归一化为 region weights。

region 内 uniform。

这是为了回答：

> 需要 residue-level，还是 CDR-region level 已经够？

---

# 39. C1 先跑小 pilot

不要直接 500 steps 全跑。

先：

```text
4 train cases
4 held-out cases
100 updates
```

B1/B2/B3。

要求：

```text
训练稳定
invalid 不升
reward 有信号
```

再扩：

```text
24 train
8 held-out
500 updates
```

---

# 40. Spatial DPO checkpoint 选择

和 Round-1 完全一样：

```text
held-out 8
```

每 50 steps：

```text
8 samples/case
```

选择：

```text
reward highest
AND invalid <= base +1pp
AND FR mismatch = 0
```

不能看 valid100。

---

# 41. Phase C 评测成功标准

和 N3 比。

N3：

```text
Δ reward = +2.796
CDR RMSD = 2.090
```

定义：

## Strong success

如果 CF-DPO：

```text
valid100 Δ reward >= +2.50
AND
CDR RMSD <= 2.00 Å
```

或者：

```text
reward 与 N3 无显著下降
AND
CDR RMSD 相比 N3 改善 >= 0.10 Å
```

则：

```text
Spatial credit assignment = SUCCESS
```

---

## Partial success

如果：

```text
reward >= +2.4
CDR RMSD 改善 0.05–0.10 Å
```

仍值得继续 Temporal。

---

## Failure

如果：

```text
reward 明显掉
且 geometry 不改善
```

则 counterfactual weighting 当前形式不成立。

先检查：

```text
credit consistency
weight concentration
epistasis
```

不要直接加更多模块。

---

# 42. Refold protocol：必须固定同一批 case

使用 Round-1 完全相同的：

```text
20 valid100 cases
4 sequences/case
same seeds
```

这样：

```text
Base/N2/N3/N4/CF
```

可以直接 paired comparison。

不要重新随机抽 20 case。

---

# 43. Phase D — Temporal credit DPO

只有 Gate B 至少 Medium/Strong 才做。

---

# 44. D1：Temporal-only DPO

仍然用 N3 的 uniform fake residue mask。

只改：

```text
DPO preference loss 的 timestep weight
```

对每个 sampled sigma：

\[
L =
g(\sigma)
L_{\mathrm{DPO}}
\]

日志同时输出：

```text
raw_dpo_loss
weighted_dpo_loss
g_sigma
sigma
```

---

# 45. 注意 DPO init Gate

因为 weighted loss 不再等于 log2：

仍然检查：

```text
raw DPO loss ≈ 0.693
```

weighted loss：

```text
≈ g(sigma) * 0.693
```

不能用 weighted loss 做 init correctness gate。

---

# 46. Temporal Control

至少比较：

## T0
N3 original sigma distribution。

## T1
hard low-noise gate：

```text
sigma <= sigma_seq
```

## T2
smooth data-driven g(sigma)。

若 T2 不优于简单 T1：

不要强行包装复杂 schedule。

---

# 47. D2：Spatial + Temporal Combined

如果：

```text
CF-DPO 有效
AND
Temporal-DPO 有效
```

再做：

\[
\boxed{
L_{ST}
=
g(\sigma)
L_{CF-DPO}
}
\]

也就是：

```text
residue weights = counterfactual credit
timestep weights = sequence-emergence schedule
```

不加 N4 anchor。

先单纯测试 credit assignment 本身。

---

# 48. 为什么暂时不加 structural anchor

因为我们需要隔离：

```text
空间 credit
时间 credit
```

到底能不能解决一部分 geometry degradation。

如果一开始：

```text
CF + temporal + anchor + new reward
```

最后无法知道谁有效。

所以当前实验严格：

```text
reward 不变
pair 不变
model 不变
training scope 不变
beta 尽量不变
```

只改变：

```text
credit assignment
```

---

# 49. 若 CF-ST-DPO 仍不能解决 geometry，下一步才研究 constraint

如果：

```text
reward 仍高
但 CDR RMSD 仍 >= 2.08
```

才进入第二条路线：

```text
Structural Compatibility Constraint
```

本任务书只做 proxy screening，不直接实现最终 constrained optimization。

---

# 50. Structural proxy screening（可并行，但不进训练）

利用现有 400 条 refold sample，计算候选 cheap proxy：

1. ProteinMPNN log-likelihood：
   \[
   \log p(S|X_{backbone})
   \]

2. BoltzGen IF log-likelihood：
   \[
   \log p_{IF}(S|X)
   \]

3. 若已有可直接运行的 Protenix/Boltz confidence cheap mode：
   ```text
   confidence / pLDDT proxy
   ```

4. 其它已有项目中不需要新训练的 compatibility score。

---

# 51. Proxy screening 指标

不要只看跨 arm Pearson。

必须：

## Global correlation

```text
proxy vs CDR RMSD
```

## Within-case pairwise concordance

同一个：

```text
case + arm
```

两条 sequence：

如果：

```text
proxy(A) > proxy(B)
```

是否通常：

```text
RMSD(A) < RMSD(B)
```

输出 pairwise AUC / accuracy。

## Within-case demeaned correlation

先：

```text
metric - case mean
```

再算相关。

减少 case difficulty confounding。

---

# 52. Proxy Gate

一个 proxy 只有满足至少一项：

```text
|Spearman| >= 0.35
```

或：

```text
within-case ranking accuracy >= 0.65
```

才值得下一阶段做 constraint。

否则不要把它塞进 loss。

---

# 53. 训练参数

尽量与 N3 保持一致。

```yaml
base:
  checkpoint: same as native round1
  sampling_steps: 50

dpo:
  beta: 10.0

optimizer:
  lr: 1.0e-5
  weight_decay: 0.0
  max_grad_norm: 1.0

train:
  train_module: structure_module.score_model
  max_steps: 500
  eval_every: 50
  checkpoint_every: 50
```

除非数值不稳定，否则本阶段不要重新做大 beta sweep。

---

# 54. 固定随机性

所有新 arm：

```text
same train pair order seed
same paired sigma/noise seed
same rigid augmentation seed
same held-out generation seeds
same valid100 generation seeds
```

尽量与 N3 对齐。

这样可以做 paired analysis。

---

# 55. 需要新增的 unit tests

## `test_counterfactual_sequence.py`

```text
只改一个 residue
FR unchanged
AA20 valid
```

## `test_credit_math.py`

人工 reward：

```text
c_drop
c_gain
c_avg
c_cons
```

计算正确。

## `test_credit_weights.py`

```text
weights >= 0
sum(weights)=1
uniform floor 正确
```

## `test_residue_atom_mapping.py`

每个 CDR residue：

```text
对应自己的 atom14 fake atom slots
不串 residue
```

## `test_weighted_loss_uniform_equivalence.py`

如果：

```text
所有 residue weight uniform
```

新 weighted loss 应与旧 N3 fake-mask loss 数值一致。

这是最重要 regression test。

目标：

```text
abs diff < 1e-5 FP32
```

## `test_weight_shuffle.py`

shuffle 只改变 residue-weight 对应，不改变 weight multiset。

## `test_temporal_schedule.py`

```text
sigma high → g low
sigma low → g high
monotonic
```

---

# 56. Weighted DPO Regression Gate

使用旧 N3 pair。

把 CF weights 强制设成 uniform。

运行：

```text
old N3 loss
new weighted-DPO loss
```

要求：

```text
DPO z
loss
gradient norm
```

全部近似一致。

否则不要训练。

---

# 57. Counterfactual scorer cache

新建：

```text
runs/next_stage/scorer_cache.sqlite
```

key：

```text
sequence SHA1 + scorer version/hash
```

避免重复 query。

必须记录：

```text
scorer git/version
model hash
objective name
```

防止以后 scorer 变化污染 cache。

---

# 58. 结果主表

最终：

| Method | valid100 CDR reward | Δ reward | CDR RMSD | CDR3 RMSD | pLDDT(CDR) | invalid | unique |
|---|---:|---:|---:|---:|---:|---:|---:|
| Base | | | | | | | |
| N2 Full | | | | | | | |
| N3 Uniform Fake | | | | | | | |
| Random Sparse | | | | | | | |
| Shuffle Credit | | | | | | | |
| Region-CF | | | | | | | |
| Residue-CF | | | | | | | |
| Temporal only | | | | | | | |
| **CF-ST-DPO** | | | | | | | |

---

# 59. 重点不是单一最大 reward

必须画：

```text
x = Δ CDR RMSD
y = Δ classifier reward
```

每个方法一个点。

Base 在：

```text
(0,0)
```

我们希望：

```text
CF / ST 方法
```

位于 N3 的左上方：

```text
reward 接近或更高
geometry penalty 更低
```

这是当前最关键图。

---

# 60. Pareto 判断

一个新方法 \(A\) 如果：

```text
reward_A >= reward_N3 - tolerance
AND
RMSD_A < RMSD_N3
```

则认为在 N3 上有实质改进。

建议 tolerance：

```text
0.2 CDR margin
```

但统计报告仍用 bootstrap/Wilcoxon，不只看阈值。

---

# 61. Statistical analysis

valid100：

```text
per-case mean reward
```

和 N3 paired：

```text
Wilcoxon
bootstrap 95% CI
win/tie/loss
```

refold 20 case：

按：

```text
case-level mean of 4 samples
```

做 paired bootstrap / Wilcoxon。

不要把 80 sequences 当成完全独立样本做显著性膨胀。

---

# 62. 需要画的图

## Credit

1. Counterfactual credit cumulative mass；
2. top-k credit concentration；
3. CDR1/2/3 region credit；
4. c_drop vs c_gain；
5. n_eff / n_diff histogram。

## Temporal

6. sequence recovery vs log sigma；
7. stable residue fraction vs log sigma；
8. backbone convergence vs sequence convergence；
9. reward convergence vs sigma。

## Training

10. DPO z；
11. held-out reward vs step；
12. invalid vs step。

## Final

13. reward vs RMSD Pareto；
14. valid100 per-case delta；
15. N3 vs CF-ST reward scatter；
16. N3 vs CF-ST CDR RMSD scatter。

---

# 63. `COUNTERFACTUAL_CREDIT_AUDIT.md` 必须回答

1. 平均一个 pair 有多少 residue 不同？
2. reward gap 与 mutation count 有无关系？
3. single-residue counterfactual credit 是否稀疏？
4. c_drop / c_gain 是否一致？
5. CDR1/2/3 谁贡献最大？
6. region credit 与 residue credit 是否一致？
7. 是否存在明显 epistasis？
8. H1：支持 / 部分支持 / 不支持。

---

# 64. `TEMPORAL_CREDIT_AUDIT.md` 必须回答

1. atom14 backbone 在什么时候稳定？
2. fake geometry 在什么时候稳定？
3. decoded sequence 在什么时候 valid？
4. CDR sequence 在什么时候达到 80% / 90% final recovery？
5. classifier reward 在什么时候能预测 final reward？
6. 是否存在 structure-before-sequence 的时间分离？
7. H3：支持 / 部分支持 / 不支持。
8. 给出 `sigma_seq`。

---

# 65. `NEXT_STAGE_RESULTS.md` 结构

```markdown
# Next-stage Native Atom14 Preference Results

## 1. Starting point
Round-1 N3/N4 结果。

## 2. Motivation
为什么 credit mismatch 是当前问题。

## 3. Reproduced diagnostics

## 4. Counterfactual credit audit

## 5. Diffusion temporal audit

## 6. Methods tested
- N3
- random sparse
- shuffled credit
- region credit
- residue CF
- temporal
- combined

## 7. Held-out results

## 8. valid100 reward

## 9. Refold geometry

## 10. Reward–geometry Pareto

## 11. Ablations

## 12. Failure analysis

## 13. Research decision
```

---

# 66. 下一阶段的论文判断标准

## 情况 A：最理想

如果：

```text
credit 明显稀疏
+
sequence emergence 明显晚于 backbone
+
CF-ST-DPO 保持 N3 reward
+
CDR RMSD 明显改善
```

则论文主线确定为：

\[
\boxed{
\text{Spatiotemporal Credit Assignment for Preference Alignment of Joint Sequence–Structure Diffusion}
}
\]

下一阶段再扩 general protein task。

---

## 情况 B：只有 spatial 有效

如果：

```text
CF residue weighting 有效
temporal weighting无明显收益
```

论文主线：

\[
\boxed{
\text{Counterfactual Residue Credit Assignment for Geometry-Encoded Protein Diffusion}
}
\]

不要强行保留 temporal 模块。

---

## 情况 C：只有 temporal 有效

如果：

```text
counterfactual credit diffuse
但 sequence emergence 有明显阶段性
```

则研究：

```text
sequence-aware noise scheduling / timestep preference
```

但必须进一步找 protein-specific 贡献，因为 generic diffusion 已有 timestep-aware DPO。

---

## 情况 D：两者都无效

如果：

```text
credit 不稀疏
temporal separation 也弱
```

不要继续堆复杂 DPO。

转向：

```text
Structural Compatibility Critic / constrained preference optimization
```

用 refold / MPNN likelihood 等直接研究 constraint。

---

# 67. 为什么这一阶段比“直接换结构 reward”更重要

当前 classifier reward 是项目明确要优化的 reward。

如果直接换成：

```text
refold reward
affinity reward
```

会把问题变成：

```text
换一个更合理的 oracle
```

而不是：

```text
怎样对 joint sequence–structure generator 做更好的 post-training
```

论文算法价值更弱。

当前更值得先回答：

> 同一个 sequence reward，能不能通过更正确的 credit assignment，提高 reward 而少伤结构？

如果能：

这是模型/算法创新。

如果不能：

才说明问题主要在 reward 本身。

---

# 68. 后续 generalization 暂不执行，但提前保留接口

如果 Phase D 成功，论文阶段至少需要第二个 task：

```text
general fixed-backbone protein design
或
binder/interface design
```

要求算法完全不改：

```text
sequence-level reward
→ counterfactual residue credit
→ atom14 residue geometry
→ temporal weighting
```

VHH 只作为第一个结构化 case。

本阶段不要先做 generalization。

---

# 69. OpenCode 实际执行 checklist

必须按下面顺序打勾：

```text
[ ] 复现 pair Hamming stats
[ ] 复现 reward/refold correlations
[ ] 审计 CDR position mapping
[ ] 生成 5992 左右 single-residue CF sequences
[ ] batch scorer
[ ] credit sparsity analysis
[ ] region-level counterfactual
[ ] Gate A decision

[ ] 修改 audit sampler 保存 x0 trajectory + sigma
[ ] 128 trajectories
[ ] per-step res_from_atom14
[ ] sequence/geometry convergence curves
[ ] Gate B decision

[ ] weighted DPO uniform-regression test
[ ] random sparse control
[ ] shuffled-credit control
[ ] CF-DPO 4+4 mini pilot
[ ] CF-DPO full 24/8
[ ] held-out selection
[ ] valid100
[ ] same-20-case refold
[ ] Gate C decision

[ ] temporal-only pilot if Gate B supports
[ ] combined CF-ST if both components support
[ ] final refold
[ ] NEXT_STAGE_RESULTS.md
[ ] STOP
```

---

# 70. 最后给 coding agent 的强制要求

> 不要为了“做出一个新方法”而跳过诊断实验。  
> 当前 native Diffusion-DPO 已经是很强的 baseline，下一阶段真正要找到的是它为什么在 classifier reward 上成功、却不能同时维持最好的 fold-back structural consistency。  
>
> 第一优先级是验证 spatial credit mismatch：同一 preference pair 平均约 15.6 个 CDR residue 不同，但 reward gap 与 mutation count 基本无关，因此必须通过 black-box counterfactual swaps 判断哪些 residue 真正贡献 reward。  
>
> 第二优先级是验证 temporal credit mismatch：利用 BoltzGen sampler 的 `x0_coords_traj`，确定 backbone geometry、fake geometry、decoded sequence 分别在什么 sigma 区间稳定。  
>
> 在这两个诊断成立前，不要直接实现复杂的 final method。  
>
> 若 spatial credit 成立，先把 N3 的 uniform CDR fake-atom loss 改成 counterfactual residue-weighted loss，并使用 random-sparse / shuffled-weight controls 证明“credit 对应关系”而不是“稀疏本身”带来收益。  
>
> 若 temporal separation 成立，再加入 data-driven sigma weighting。  
>
> 主 reward 始终是现有 `cdr_camelid_margin`；不要把 refold RMSD、pLDDT、MPNN likelihood 偷偷混入主 reward。  
>
> 结构指标只用于判断相同 reward 下的几何副作用是否减少。  
>
> 完成 Phase A–D 和 `NEXT_STAGE_RESULTS.md` 后停止，不自动进入 structural critic / affinity / Diffusion-GRPO。

