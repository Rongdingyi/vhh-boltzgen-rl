# Phase C refold（固定 20 cases x 4 seqs，Boltz-2 recycling=3, steps=200）

| arm | n | CDR RMSD mean | CDR3 RMSD | FR RMSD | pLDDT(CDR) | recovery |
|---|---|---|---|---|---|---|
| base | 80 | 1.860 | 2.347 | 0.559 | 0.623 | 0.291 |
| n3 | 80 | 2.090 | 2.709 | 0.578 | 0.614 | 0.281 |
| b1 | 80 | 2.154 | 2.803 | 0.567 | 0.609 | 0.258 |
| b2 | 80 | 2.064 | 2.635 | 0.554 | 0.616 | 0.276 |
| b3 | 80 | 1.949 | 2.437 | 0.610 | 0.600 | 0.282 |

## Paired CDR RMSD deltas（per case, 4 seqs/case）

| arm | vs | delta mean (A) | delta median | improved | Wilcoxon p |
|---|---|---|---|---|---|
| b1 | vs_base | +0.294 | +0.092 | 7/20 | 2.45e-01 |
| b1 | vs_n3 | +0.064 | -0.123 | 12/20 | 6.74e-01 |
| b2 | vs_base | +0.204 | +0.089 | 8/20 | 2.61e-01 |
| b2 | vs_n3 | -0.026 | +0.007 | 10/20 | 8.41e-01 |
| b3 | vs_base | +0.089 | +0.236 | 7/20 | 4.30e-01 |
| b3 | vs_n3 | -0.141 | -0.031 | 11/20 | 2.94e-01 |
