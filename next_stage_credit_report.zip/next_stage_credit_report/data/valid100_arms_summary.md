# valid100 对照（Phase C，100 cases x 8 samples）

| arm | reward mean | Δ vs base | median Δ | wins vs base | Wilcoxon p | Δ vs N3 |
|---|---|---|---|---|---|---|
| native base | 6.578 | +0.000 | +0.000 | 0/100 | n/a | -2.796 |
| B1 random_sparse | 9.361 | +2.784 | +2.270 | 86/100 | 3.84e-15 | -0.012 |
| B2 shuffle | 10.108 | +3.531 | +3.190 | 96/100 | 9.60e-18 | +0.734 |
| B3 cf | 12.143 | +5.566 | +4.855 | 99/100 | 4.40e-18 | +2.769 |
