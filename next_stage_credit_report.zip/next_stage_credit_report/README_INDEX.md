# Next-Stage Credit Research Report（数据 + 报告打包）

任务书：`taskbook/NATIVE_ATOM14_NEXT_STAGE_CREDIT_RESEARCH_TASK.md`
（Phase A–D 已完成并停止；本包为全部报告与结果数据，不含模型 checkpoint）

## 核心结论

| 阶段 | 结论 |
|---|---|
| A0 诊断复现 | 与任务书一致：Hamming mean 15.60、总差异 2996；reward vs CDR RMSD +0.019、vs pLDDT(CDR) −0.563、vs recovery −0.447 |
| A credit 稀疏性 | **Gate A = STRONG**：top30% mass 0.940、n_eff/n_diff 0.270；CDR3 主导（G_cons 3.69） |
| B 时间涌现 | **Gate B = WEAK**：σ_seq = 0.3137，无 "backbone 先收敛" 窗口，序列与几何同步涌现 |
| C 主方法（B3 CF-DPO） | **Strong success（§41）**：valid100 Δreward **+5.566**（99/100, p=4.4e-18，N3 为 +2.796）；refold CDR RMSD **1.949 Å**（≤2.00；N3 2.090） |
| C controls | B1 random_sparse +2.784（≈N3）、B2 shuffle +3.531 → credit 与残基的对应关系是关键 |
| D temporal ablation | T1 hard Δ+0.057、T2 smooth Δ+0.256（held-out），实质无效，与 Gate B=WEAK 一致 |

## 目录结构

```
README_INDEX.md                 本文件
taskbook/                       任务书原文
docs/
  NEXT_STAGE_DIAGNOSTIC_REPRO.md     A0 统计复现
  COUNTERFACTUAL_CREDIT_AUDIT.md     A1/A2 + Gate A
  TEMPORAL_CREDIT_AUDIT.md           B1 + Gate B
  NEXT_STAGE_IMPLEMENTATION.md       实现与 gate/测试说明
  NEXT_STAGE_RESULTS.md              汇总结果（§65 结构）
references/NEXT_STAGE_RELATED_WORK.md 与现有工作的边界
data/
  repro/                         pair_stats.json, refold_correlations.csv
  counterfactual/                7472 条 CF 序列/分数、residue/region/pair credit CSV、
                                 credit_stats.json、6 张图
  weights/                       residue_weights.json（η=0.75, fallback 0%）
  trajectory/                    128 trajectories：per-step metrics/sequences/summary + 2 图
  training/                      各臂 train_metrics.jsonl + train_summary.json（不含 ckpt）
  eval/                          held-out 选择（30 个 ckpt 评测）与 valid100（12 shard）汇总
  refold/                        新臂 per-sample refold 结果 + round-1 base/N3 参照
  checkpoint_selection.{json,md} 各臂最优 ckpt（§40 规则）
  valid100_arms_summary.{json,md}
  refold_phaseC.{json,md}
figures/figC_dashboard.png       valid100 Δreward 与 refold CDR RMSD 双面板
```

## 复现入口

代码在 `vhh_boltzgen_rl/`：`run.sh next-*`（见 `docs/NEXT_STAGE_IMPLEMENTATION.md`）。
模型 checkpoint（约 1.8GB/个）未包含；训练可从 `data/training/*/train_metrics.jsonl`
核对曲线，评测数据可直接从 `data/eval`、`data/refold` 复核。
