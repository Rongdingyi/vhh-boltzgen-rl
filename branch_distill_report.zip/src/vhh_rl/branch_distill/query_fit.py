"""Exact multi-branch query replay + finite local distillation fit (§31-§39).

The trained forward replays the FULL K-branch batch exactly as captured
(§31/§72: multiplicity K must not be squashed to 1); only the peer branch
slice enters the loss.
"""
from __future__ import annotations

import torch

DEVICE = "cuda"


def network_kwargs(conditioning: dict, multiplicity: int, device=DEVICE) -> dict:
    """Device-move conditioning, rebuilding captured partial callables.

    Captured conditioning stores functools.partial objects as
    {"__partial__": ...} dicts; only move_conditioning reconstructs them, so a
    plain .to(device) is not enough (nested diffusion_conditioning entries
    would stay on CPU and crash the encoders).
    """
    required = ("s_inputs", "s_trunk", "feats", "diffusion_conditioning")
    ready = (all(key in conditioning for key in required)
             and isinstance(conditioning.get("feats"), dict)
             and isinstance(conditioning.get("diffusion_conditioning"), dict))
    if ready:
        from ..native_atom14.dpo_trainer import move_conditioning
        payload = {key: conditioning[key] for key in required}
        payload = move_conditioning(payload, device=device)
    else:
        def _move(value):
            if torch.is_tensor(value):
                return value.to(device)
            if isinstance(value, dict):
                return {k: _move(v) for k, v in value.items()}
            return value
        payload = _move({key: conditioning[key] for key in conditioning
                         if key in required or key == "feats"})
    payload["multiplicity"] = multiplicity
    return payload


def forward_peer_prediction(model, *, full_query_batch: torch.Tensor,
                            sigma: float, conditioning: dict,
                            multiplicity: int, peer_index: int,
                            device=DEVICE) -> torch.Tensor:
    """Exact full-batch replay; returns the peer branch clean prediction [N,3]."""
    # official convention: the combined batch is [B*mult, N, 3] (3-dim) and
    # multiplicity tells the model how many samples share one conditioning row
    query = full_query_batch.float()
    if query.dim() == 2:
        query = query.unsqueeze(0)
    if query.dim() != 3:
        raise ValueError(f"query batch must be [B*mult, N, 3], got {tuple(query.shape)}")
    if query.shape[0] != multiplicity:
        raise ValueError(f"query batch {query.shape[0]} != multiplicity {multiplicity}")
    query = query.to(device)
    kwargs = network_kwargs(conditioning, multiplicity, device=device)
    sigma_t = torch.full((multiplicity,), float(sigma), device=device)
    denoised, _ = model.structure_module.preconditioned_network_forward(
        query, sigma_t, training=False, network_condition_kwargs=kwargs)
    return denoised.float()[int(peer_index)]


def local_distill_loss(pred: torch.Tensor, target: torch.Tensor,
                       mask: torch.Tensor) -> torch.Tensor:
    """§36: MSE over touched * fake * pad, no hold term in v1."""
    diff = (pred - target.to(pred.device).float()) ** 2
    mask = mask.to(pred.device).reshape(-1).bool()
    if not bool(mask.any()):
        raise ValueError("empty target mask")
    return diff[mask].sum(dim=-1).mean()


def masked_mse(pred: torch.Tensor, target: torch.Tensor, mask: torch.Tensor) -> float:
    return float(local_distill_loss(pred, target, mask).detach())


def record_target_mask(record) -> torch.Tensor:
    """§36 target mask: touched & fake_atom & atom_pad."""
    feats = record.conditioning["feats"]
    pad = feats["atom_pad_mask"].reshape(-1).bool()
    fake = feats["fake_atom_mask"].reshape(-1).bool()
    return record.touched_mask.reshape(-1).bool() & fake & pad


def fit_record(base_checkpoint, record, *, updates: int = 40, lr: float = 1e-5,
               max_grad_norm: float = 1.0, device=DEVICE) -> dict:
    """One-record overfit from a fresh base student (§35); returns the student."""
    from ..native_atom14.checkpoint import (
        load_base_model, make_policy_reference, parameter_drift,
        trainable_score_params,
    )

    base = load_base_model(base_checkpoint, device=device)
    student, reference = make_policy_reference(base, device=device)
    params = trainable_score_params(student)
    optimizer = torch.optim.AdamW(params, lr=lr, weight_decay=0.0)

    mask = record_target_mask(record)
    pred = forward_peer_prediction(student, full_query_batch=record.full_query_batch,
                                   sigma=record.meta["sigma"], conditioning=record.conditioning,
                                   multiplicity=record.branch_count,
                                   peer_index=record.peer_index, device=device)
    initial = masked_mse(pred, record.target_coords, mask)
    history = []
    for step in range(1, int(updates) + 1):
        pred = forward_peer_prediction(student, full_query_batch=record.full_query_batch,
                                       sigma=record.meta["sigma"],
                                       conditioning=record.conditioning,
                                       multiplicity=record.branch_count,
                                       peer_index=record.peer_index, device=device)
        loss = local_distill_loss(pred, record.target_coords, mask)
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        grad_norm = torch.nn.utils.clip_grad_norm_(params, max_grad_norm)
        optimizer.step()
        history.append({"step": step, "loss": float(loss.detach()),
                        "grad_norm": float(grad_norm)})
    pred = forward_peer_prediction(student, full_query_batch=record.full_query_batch,
                                   sigma=record.meta["sigma"],
                                   conditioning=record.conditioning,
                                   multiplicity=record.branch_count,
                                   peer_index=record.peer_index, device=device)
    final = masked_mse(pred, record.target_coords, mask)
    drift = parameter_drift(student, reference)
    return {
        "student": student,
        "reference": reference,
        "initial_masked_mse": initial,
        "final_masked_mse": final,
        "mse_ratio": (final / initial) if initial > 0 else None,
        "param_drift": drift["total"],
        "history": history,
    }
