# CF-DPO v2 Report（数据 + 报告打包）

对应仓库 commit：`788de98`（vhh-boltzgen-rl main，CI green）。
本包记录 CF-DPO v2（Counterfactual Preference Correction with
Outcome-Consistent Alignment）的完整可行性轮：两轮审阅修复 + 唯一一轮小规模重跑。

## 最终结论

**NO-GO（针对 "global denoising-energy potential + BCE local graph fitting" 的 v2 形态），
基于修正后的有效实验**（早期 NO-GO 曾因 4 个代码错误被撤回为 INVALID，见 ERRATA）。

| 臂（4 train / 4 held-out，matched 50/100 updates） | held-out reward | Δ vs base | wins |
|---|---|---|---|
| base | −1.206 | — | — |
| **CF-DPO-mini u100** | **+3.186** | **+4.392** | **4/4** |
| v2 u100 | +0.044 | +1.250 | 3/4 |
| v2 u50 | −0.378 | +0.829 | 2/4 |
| signed u100 | −1.187 | +0.020 | 2/4 |
| signed u50 | −0.900 | +0.307 | 3/4 |

- **Proxy 校验**（nσ=32，分层抽样，真值由节点 reward 重算）：label mismatch **0**，
  符号一致率 **0.615**，噪声/信号 **≈6.7×** → 能量代理局部排序不可靠。
- **Exp2 精确小模型（忠实 per-site 加权对照）**：signed/v2 序列 KL 0.0005–0.0007
  （sign acc 0.994）vs 加权类 6.2–7.2（0.64–0.65）；v2 同结果边使条件几何 KL→0.0000。
- **Exp3 合法几何 lift**：192 尝试 / 167 精确（86.5%）、FR mismatch 0、
  同序列 M=2 覆盖 100%（Gate PASS）。
- 失败机制：局部 residue preference 经全结构 energy proxy 后 SNR<1；
  CF-DPO 的局部 credit→局部 fake-atom error 路径信号集中，因此保持主线。

## 审阅修复记录（两轮）

**第一轮（ERRATA，commit de8f5c9 → bec73ef）**
1. `winner_drop` 边 dR 方向写反（改为 R(CF)−R(winner)）
2. counterfactual node ID 冲突静默覆盖（ID 含双方 sample id；重复即抛错；图 346→565 节点）
3. same-seq 边被双重采样（~53% → 25%）
4. Exp2 基线 z 方向与 drop 边符号写反
5. proxy ground truth 被污染（改用节点 reward + 分层抽样）

**第二轮（commit 32c705c → 3dcc3bf → 788de98）**
6. signed 采样比例 81.25/18.75 → 75/25
7. Exp2 `current_cf` 的 `mean(w_i)` 退化（改为 per-site 条件损失加权 DPO）
8. rerun 训练目录混旧 log（训练前清理）
9. graph invariant 移入 production（`save_graph` 强制断言 + CI 测试）
10. κ 校准：无更新校准在 policy=reference 处 h≡0（钳到 1e8，该轮作废）→ 改为
    warmup 10 步 → 恢复 base → 固定 κ_eff（signed 1.52e4 / v2 9.34e3）

## 目录

```
README_INDEX.md
docs/                      7 篇：DECISION / ERRATA / EXP2_SMALL_MODEL /
                           EXP2_COUNTEREXAMPLE / EXP3_GEOMETRY_LIFT /
                           EXP3_PROXY_VALIDATION / EXP4_PILOT
proposal_package/          原始方案包：PROPOSAL、SIGNED_CREDIT_REAUDIT、
                           audit_and_math_checks.py、math_checks.json、
                           signed_credit_audit.json、per_pair_reaudit.csv、
                           signed_credit_counts.csv、source_data/
data/
  small_model/             Exp2 summary.json + counterexample.json + 表格
  geometry_lift/           lift_summary.json、lift_attempts.csv、same_seq.json
  graph/                   graph_summary.json + pilot_graph.pt（565 节点/366 边）
  proxy_validation/        proxy_checkpoint_0100.json（nσ=32 明细）
  training/                signed/v2（含 uncalibrated 对照）train_metrics、
                           train_summary、calibration、eval_summary；
                           cf_dpo_mini_and_base_pilot_eval.json
  exp4_pilot.json          最终对比表
```

不含模型 checkpoint（每个 ~1.8GB）；不含评测生成池（仅 eval_summary）。
