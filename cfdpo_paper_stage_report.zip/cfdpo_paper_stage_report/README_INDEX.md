# CF-DPO Paper-stage Report（数据 + 报告打包）

任务书：`taskbook/CF_DPO_PAPER_STAGE_EXPERIMENT_PLAN.md`（P0/P1 完成，P2 不执行，按 §71 停止）
协议：`configs/FROZEN_PROTOCOL.yaml`（全部哈希已校验；不含模型 checkpoint）

## 核心结论

| 实验 | 结论 |
|---|---|
| **P0-A multi-seed**（3 seeds） | CF **+4.925 ± 0.563**，3/3 seed Δ>+4.0 ✓；N3 +3.838 ± 0.904；Shuffle +3.608 ± 0.105。**但 CF−N3 均值 +1.087 < +2.0（gate FAIL）**，primary 的 +2.77 不稳健 |
| **P0-B attribution ablation** | 排序符合理想图景：**CF +5.566 > gain +5.258 > drop +4.932 > diff-only +4.221 > shuffle +3.531 > N3 +2.796**；CF > Diff-only **+1.345**（关键因果项 ✓） |
| **P0-C 结构（Boltz-2 100-case）** | N3 1.780 < CF 1.854（+0.074 Å, p=0.17）；20-case 有利趋势未复现 |
| **P0-C 独立 refolder（Protenix 50-case）** | N3 5.134 < CF 5.915（+0.78, p=0.18）；与 Boltz-2 一致：CF 不优于 N3 |
| **P1-A query budget** | 25/50/75/100% queries → +4.27/+4.72/+4.98/+5.57；**50% 拿到 84.8% 增益** ✓ |
| **P1-B 第二 reward（ESM-C CDR PLL）** | Uniform +0.339 / CF +0.366（8/8 vs base）；**CF vs Uniform +0.027，6/8**（pilot 通过） |
| **P2** | 不执行（理由见 `docs/P2_GENERALIZATION.md`） |

## 最终判定（PAPER_STAGE_RESULTS §15）

- **不支持原 headline**："CF ≫ N3"、"CF improves structural consistency"
- **强支持**：attribution-chain —— credit 稀疏（C1）+ 对应关系（C2，CF>diff-only>shuffle>N3）+ query-budget 效率
- 决策：**Need one more generalization experiment + claim re-scope**（第二 reward 补 valid100；主线改为 counterfactual credit correspondence）

## 目录结构

```
README_INDEX.md                       本文件
taskbook/                             任务书原文
configs/FROZEN_PROTOCOL.yaml          冻结协议
docs/                                 P0_MULTISEED / P0_CREDIT_ABLATIONS /
                                      P0_STRUCTURE_VALIDATION / P1_QUERY_BUDGET /
                                      P1_SECOND_REWARD / P2_GENERALIZATION /
                                      PAPER_STAGE_RESULTS
results/                              全部 CSV 表 + figures/figA–figE
data/
  training/                           13 个训练 run 的 metrics + summary（不含 ckpt）
  multiseed/valid100/ablations/query_budget/  checkpoint 选择与 valid100 汇总
  second_reward/                      审计、pairs、credit、权重、sweep 打分、held-out 汇总
  structure/                          Boltz-2 / Protenix 结构与统计
  eval_summary_paper_*.json           held-out 选择与 valid100 全部评测原始汇总
```

## 复现入口

`vhh_boltzgen_rl/run.sh paper-freeze-protocol | paper-multiseed-* | paper-ablate-* | paper-query-budget | paper-second-reward-* | paper-structure-* | paper-report`
