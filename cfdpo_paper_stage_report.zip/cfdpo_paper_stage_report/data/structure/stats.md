# Protenix-v2 independent refold (50 cases x 2 seqs, case-level)

- base: CDR RMSD mean = 6.827 (n=50)
- n3: CDR RMSD mean = 5.134 (n=50)
- cf: CDR RMSD mean = 5.915 (n=50)
- CF vs base: Δ mean -0.911 Å, CI [-1.898, +0.082], W/L 31/19, p=0.04610038786489312
- CF vs n3: Δ mean +0.781 Å, CI [-0.343, +1.942], W/L 19/31, p=0.18444897927691706
