# Paper-stage checkpoint selection（held-out 8 cases, task book §54）

base held-out reward = +1.271

| run | arm | seed | selected step | held-out reward |
|---|---|---|---|---|
| cf_s43 | cf | 43 | 400 | +6.571 |
| cf_s44 | cf | 44 | 450 | +6.853 |
| n3_s43 | n3 | 43 | 500 | +5.868 |
| n3_s44 | n3 | 44 | 500 | +6.551 |
| shuffle_s43 | shuffle | 43 | 450 | +4.908 |
| shuffle_s44 | shuffle | 44 | 500 | +4.753 |
| n3_primary | n3 | 20260913 | 350 | (round-1 selected) |
| shuffle_primary | shuffle | 20260913 | 450 | (round-1 selected) |
| cf_primary | cf | 20260913 | 500 | (round-1 selected) |
