# Second-reward (VHH-ESM-C CDR PLL) held-out comparison

Base: cdr_pll mean = -2.0560

| arm | cdr_pll mean | Δ vs base | wins | Wilcoxon p |
|---|---|---|---|---|
| sr_uniform | -1.7166 | +0.3394 | 8/8 | 0.00781 |
| sr_cf | -1.6897 | +0.3663 | 8/8 | 0.00781 |

**CF vs Uniform (second reward)**: delta mean +0.0269, wins 6/8, p=0.3828125
